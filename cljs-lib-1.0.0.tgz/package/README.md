# cljs-lib

`cljs-lib` is a ClojureScript library packaged as an ES module for React and TypeScript projects.

It currently exports:

- `greet(name)`: returns a greeting string.
- `processTransactions(payload)`: validates, normalizes, summarizes, and risk-scores transaction data.

The published package entry points are configured in `package.json`:

- Runtime ESM entry: `out/lib/main.js`
- TypeScript declarations: `types/index.d.ts`

## Requirements

Install these tools before developing or packaging the library:

- Node.js
- npm
- Java runtime, required by `shadow-cljs`

The package is built with `shadow-cljs`.

## Project Structure

```text
src/my_demo_clj/core.cljs       ClojureScript source and exported functions
test/my_demo_clj/core_test.cljs ClojureScript tests
types/index.d.ts                TypeScript declarations for consumers
shadow-cljs.edn                 ClojureScript build and test config
package.json                    npm package metadata, exports, scripts
out/lib/main.js                 Generated ESM bundle after build
```

## Development

Install dependencies:

```bash
npm install
```

Run tests:

```bash
npm test
```

Build the ESM library:

```bash
npm run build
```

The build writes the distributable JavaScript file to:

```text
out/lib/main.js
```

## Package For Another Project

Before sending the library to another computer or another project, run:

```bash
npm test
npm run build
npm pack
```

`npm pack` creates a tarball like:

```text
cljs-lib-1.0.0.tgz
```

This `.tgz` file is the recommended artifact to copy to another computer.

The packed package includes only the files needed by consumers:

```text
out/lib/main.js
types/index.d.ts
package.json
README.md
LICENSE
```

Do not copy `node_modules`, `src`, `test`, `target`, or `.shadow-cljs` for normal library consumption.

## Install In A React/TypeScript Project

Copy `cljs-lib-1.0.0.tgz` into the target Web project, then install it.

With npm:

```bash
npm install ./cljs-lib-1.0.0.tgz
```

With pnpm:

```bash
pnpm add ./cljs-lib-1.0.0.tgz
```

With Yarn:

```bash
yarn add ./cljs-lib-1.0.0.tgz
```

Then import it from TypeScript or React code:

```ts
import { processTransactions, greet } from "cljs-lib";

console.log(greet("Ada"));

const summary = processTransactions({
  transactions: [
    {
      id: "tx-1",
      amount: "1200",
      category: "books",
      status: "paid",
      customerId: "customer-1",
      timestamp: "2026-04-21T00:00:00.000Z",
    },
  ],
  rules: {
    highValueThreshold: 1000,
  },
});

console.log(summary.totalCount);
console.log(summary.processed[0].riskScore);
```

TypeScript reads the declarations from `types/index.d.ts` automatically through the package `types` and `exports` fields.

## API

### `greet(name)`

```ts
function greet(name: string): string;
```

Returns a greeting message.

Example:

```ts
import { greet } from "cljs-lib";

const message = greet("Ada");
// "Hello, Ada! Welcome to ClojureScript."
```

### `processTransactions(payload)`

```ts
function processTransactions(
  payload: TransactionInput[] | TransactionPayload
): TransactionSummary;
```

Accepts either a raw transaction array:

```ts
import { processTransactions } from "cljs-lib";

const summary = processTransactions([
  {
    amount: 1000,
    status: "paid",
    timestamp: "2026-04-21T00:00:00.000Z",
  },
]);
```

Or an object with transactions and processing rules:

```ts
import { processTransactions } from "cljs-lib";

const summary = processTransactions({
  transactions: [
    {
      id: "tx-1",
      amount: "2500",
      category: "books",
      status: "disputed",
      customerId: "customer-1",
      timestamp: "2026-04-21T00:00:00.000Z",
    },
  ],
  rules: {
    highValueThreshold: 1000,
  },
});
```

### Input Types

```ts
type TransactionStatus =
  | "paid"
  | "failed"
  | "refunded"
  | "disputed"
  | "unknown"
  | (string & {});

interface TransactionInput {
  id?: string | number;
  amount?: number | string;
  category?: string;
  status?: TransactionStatus;
  customerId?: string | number;
  timestamp?: string | number | Date;
  [key: string]: unknown;
}

interface ProcessingRules {
  highValueThreshold?: number | string;
}

interface TransactionPayload {
  transactions?: TransactionInput[];
  rules?: ProcessingRules;
}
```

Required fields for a valid transaction:

- `amount`: must be a finite number or numeric string.
- `timestamp`: must be a valid JavaScript `Date` input.

Optional defaults:

- `id`: defaults to `tx-<index>`.
- `category`: defaults to `uncategorized`.
- `status`: defaults to `unknown`.
- `customerId`: defaults to `anonymous`.
- `rules.highValueThreshold`: defaults to `1000`.

### Output Type

```ts
interface TransactionSummary {
  totalCount: number;
  validCount: number;
  invalidCount: number;
  totalAmount: number;
  averageAmount: number;
  threshold: number;
  processed: ProcessedTransaction[];
  invalid: InvalidTransaction[];
  highValue: ProcessedTransaction[];
  categorySummary: Record<string, CategorySummary>;
  statusSummary: Record<string, number>;
}
```

All returned fields use frontend-friendly camelCase names.

Example output shape:

```ts
{
  totalCount: 2,
  validCount: 1,
  invalidCount: 1,
  totalAmount: 1200,
  averageAmount: 1200,
  threshold: 1000,
  processed: [
    {
      valid: true,
      id: "tx-1",
      amount: 1200,
      category: "books",
      status: "paid",
      customerId: "customer-1",
      timestamp: "2026-04-21T00:00:00.000Z",
      epochMs: 1776729600000,
      raw: {},
      riskScore: 35,
      riskLevel: "medium"
    }
  ],
  invalid: [],
  highValue: [
    {
      valid: true,
      id: "tx-1",
      amount: 1200,
      category: "books",
      status: "paid",
      customerId: "customer-1",
      timestamp: "2026-04-21T00:00:00.000Z",
      epochMs: 1776729600000,
      raw: {},
      riskScore: 35,
      riskLevel: "medium"
    }
  ],
  categorySummary: {
    books: {
      count: 1,
      amount: 1200
    }
  },
  statusSummary: {
    paid: 1
  }
}
```

## Risk Scoring

`processTransactions` adds a `riskScore` from `0` to `100` and a `riskLevel`.

Amount score:

- `45`: amount is at least `highValueThreshold * 2`.
- `25`: amount is at least `highValueThreshold`.
- `0`: amount is below `highValueThreshold`.

Status score:

- `35`: `disputed`
- `20`: `failed`
- `15`: `refunded`
- `0`: any other status

Customer score:

- `10`: first time this customer appears in the payload.
- `0`: customer has already appeared earlier in the same payload.

Risk levels:

- `critical`: score >= 70
- `high`: score >= 45
- `medium`: score >= 20
- `low`: score < 20

## Package Metadata

The package is ESM-only:

```json
{
  "type": "module",
  "exports": {
    ".": {
      "types": "./types/index.d.ts",
      "import": "./out/lib/main.js",
      "default": "./out/lib/main.js"
    }
  }
}
```

This works with modern React tooling such as Vite, Next.js, Webpack, and other bundlers that support ES modules.

## Versioning

When distributing a new build, update the package version before packing:

```bash
npm version patch
npm run build
npm pack
```

Then install the new `.tgz` in the target Web project:

```bash
npm install ./cljs-lib-1.0.1.tgz
```

If the target project still uses an old version, remove the old package lock entry or reinstall with the new tarball path.

## Troubleshooting

### TypeScript cannot find types

Confirm the installed package contains:

```text
types/index.d.ts
```

Also confirm the package was installed from the generated `.tgz`, not from a partially copied directory.

### Node complains about ESM

This package is ESM-only. The consuming project should use `import` syntax:

```ts
import { processTransactions } from "cljs-lib";
```

Do not use CommonJS `require("cljs-lib")` unless your build system transpiles ESM interop correctly.

### Changes are not reflected in the target project

Rebuild and repack the library:

```bash
npm run build
npm pack
```

Then reinstall the new tarball in the target project:

```bash
npm install ./cljs-lib-1.0.0.tgz
```

For repeated changes, increment the version number before packing.

### `npm pack` reports cache permission errors

If npm reports permission errors in `~/.npm`, use a temporary cache:

```bash
npm pack --cache /tmp/my-demo-clj-npm-cache
```

This avoids local npm cache ownership problems.

## License

Copyright © 2026 FIXME

This program and the accompanying materials are made available under the terms of the Eclipse Public License 2.0.
