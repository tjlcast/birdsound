export type TransactionStatus =
  | "paid"
  | "failed"
  | "refunded"
  | "disputed"
  | "unknown"
  | (string & {});

export type RiskLevel = "low" | "medium" | "high" | "critical";

export interface TransactionInput {
  id?: string | number;
  amount?: number | string;
  category?: string;
  status?: TransactionStatus;
  customerId?: string | number;
  timestamp?: string | number | Date;
  [key: string]: unknown;
}

export interface ProcessingRules {
  highValueThreshold?: number | string;
}

export interface TransactionPayload {
  transactions?: TransactionInput[];
  rules?: ProcessingRules;
}

export interface ProcessedTransaction {
  valid: true;
  id: string;
  amount: number;
  category: string;
  status: string;
  customerId: string;
  timestamp: string;
  epochMs: number;
  raw: TransactionInput;
  riskScore: number;
  riskLevel: RiskLevel;
}

export interface InvalidTransaction {
  valid: false;
  id: string;
  index: number;
  errors: string[];
  raw: TransactionInput;
}

export interface CategorySummary {
  count: number;
  amount: number;
}

export interface TransactionSummary {
  totalCount: number;
  validCount: number;
  invalidCount: number;
  totalAmount: number;
  averageAmount: number;
  threshold: number;
  processed: ProcessedTransaction[];
  invalid: InvalidTransaction[];
  highValue: ProcessedTransaction[];
  categorySummary: Record<string, CategorySummary>;
  statusSummary: Record<string, number>;
}

export function greet(name: string): string;

export function processTransactions(
  payload: TransactionInput[] | TransactionPayload
): TransactionSummary;
